# projetS3
 clone de Tetris en C
avec SDL,SDL_image,SDL_ttf,SDL_mixer
